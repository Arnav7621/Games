 /*let uscore=0;
 let compscore=0;

 const choices=document.querySelectorAll(".choice");


const cchoice=() =>{
    const options=["rock","paper","scissor"];
    const compindex= Math.floor(Math.random()*3);
    return options[compindex];
 };
 const draw=()=>{
    msg.innertext="Draw...play again";
 };
 const game =(userchoice)=>{
    const compChoice=cchoice();
     if (userChoice === compChoice) {
    
    draw();
  } else {
    let userWin = true;
    if (userChoice === "rock") {
      
      userWin = compChoice === "paper" ? false : true;
    } else if (userChoice === "paper") {
      
      userWin = compChoice === "scissors" ? false : true;
    } else {
      
      userWin = compChoice === "rock" ? false : true;
    }
    
    console.log(compchoice);


 }
};

 choices.forEach((choice)=>{
    choice.addEventListener("click",()=>{
        const userChoice=choice.getAttribute("id");
        console.log(userChoice);
        game(userChoice);
    });
 });
*/
let uscore = 0;
let compscore = 0;


const choices = document.querySelectorAll(".choice");
const msg = document.querySelector("#msg");

const userScorePara = document.querySelector("#uscore");

const compScorePara = document.querySelector("#compscore");

const cchoice = () => {
    const options = ["rock", "paper", "scissors"]; 
    const compindex = Math.floor(Math.random() * 3);
    return options[compindex];
};

const draw = () => {
    msg.innerText = "Draw...play again";
};

const game = (userChoice) => {
    const compChoice = cchoice();
    console.log("Computer choice:", compChoice); 

    if (userChoice === compChoice) {
        draw();
    } else {
        let userWin = true;
        if (userChoice === "rock") {
            userWin = compChoice === "paper" ? false : true;
        } else if (userChoice === "paper") {
            userWin = compChoice === "scissors" ? false : true;
        } else {
            userWin = compChoice === "rock" ? false : true;
        }

        if (userWin) {
            uscore++;
            msg.innerText = `You win! Score: User ${uscore} - Computer ${compscore}`;
            // userScorePara.innertext=uscore;
            userScorePara.innerHTML= uscore
            console.log(uscore);
            // console.log(userScorePara);
            
        } else {
            compscore++;
            msg.innerText = `Computer wins! Score: User ${uscore} - Computer ${compscore}`;
            compScorePara.innerHTML=compscore;
        }
    }
    

};

choices.forEach((choice) => {
    choice.addEventListener("click", () => {
        const userChoice = choice.getAttribute("id");
        console.log("User choice:", userChoice); 
        game(userChoice);
    });
});

 
 